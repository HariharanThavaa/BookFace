// go to Create Author Screen
function createAuthor(){
    window.location = "/authors?type=Create";
}

function addAuthor(){
	var txtAuthorName = document.getElementById("txtAuthorName").value;
	var txtAuthorDesc = document.getElementById("txtAuthorDesc").value;

	if( txtAuthorName === ''){
		alert("Please provide Author Name");
	}else if (txtAuthorDesc === ''){
		alert("Please provide Author Description");
	}else{
		// Send POST Request here
		fetch('authors', {
		    method: 'post',
		    headers: {'Content-Type': 'application/json'},
		    body: JSON.stringify({
		      'name': txtAuthorName,
		      'desc': txtAuthorDesc
		    })
		}).then(res => {
			window.location = "/";
		})

	}
}

// go to View Author Screen
function readAuthor(id){
    window.location = "/authors?type=Read&_id="+id;
}


// go to update Author Screen
function updateAuthor(id){
    window.location = "/authors?type=Update&_id="+id;
}

// Edit Author details
function editAuthor(){
	var txtAuthorName = document.getElementById("txtAuthorName").value;
	var txtAuthorDesc = document.getElementById("txtAuthorDesc").value;
	var txtAuthorId = document.getElementById("txtAuthorId").value;


	if( txtAuthorName === ''){
		alert("Please provide Author Name");
	}else if (txtAuthorDesc === ''){
		alert("Please provide Author Description");
	}else{
		// Send PUT Request here
		fetch('authors', {
		    method: 'put',
		    headers: {'Content-Type': 'application/json'},
		    body: JSON.stringify({
			  '_id': txtAuthorId,
		      'name': txtAuthorName,
		      'desc': txtAuthorDesc
		    })
		}).then(res => {
			window.location = "/";
		})

	}
}

//delete Author
function deleteAuthor(id){
    fetch('authors', {
	    method: 'delete',
	    headers: {
	      'Content-Type': 'application/json'
	    },
	    body: JSON.stringify({
	      '_id': id
	    })
	  })
	  .then(res => {
	    if (res.ok) return res.json()
	  }).
	  then(data => {
	    console.log(data)
	    window.location.reload()
  })
}

//go back to main screen cancel button
function listAuthor(){
    window.location = "/";
}

//=========================================================================
//Books Functionalities Starts here
//=========================================================================

