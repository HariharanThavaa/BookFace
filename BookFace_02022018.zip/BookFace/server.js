const express = require('express');
const bodyParser = require('body-parser')
const app = express();
app.set('view engine','ejs')
app.use(bodyParser.json())
app.use(express.static('public'))
const MongoClient = require('mongodb').MongoClient
var ObjectId = require('mongodb').ObjectId


var uri = "mongodb://harimaniam:Password@cluster0-shard-00-00-kqjyc.mongodb.net:27017,cluster0-shard-00-01-kqjyc.mongodb.net:27017,cluster0-shard-00-02-kqjyc.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin";
var db

MongoClient.connect(uri, (err, database) => {
  if (err) return console.log(err)
  db = database.db('star-wars-quotes')
  app.listen(3000, () => {
    console.log('listening on 3000')
  })
})

app.use(bodyParser.urlencoded({extended: true}))

app.get('/', (req, res) => {
	console.log("app get")
  db.collection('authors').find().toArray((err, result) => {

    if (err) return console.log(err)
    // renders index.ejs
    res.render('index.ejs', {authors: result})
  })
})


// Add/Edit/View Authors Screen
app.get('/authors', (req, res) => {
	if ((typeof(req.query._id) !== 'undefined') && (req.query._id!== null)) {
		console.log("id is :: " + req.query._id )

		db.collection('authors')
		  .findOne({_id:ObjectId(req.query._id)}, (err, result) => {
		   if (err) return console.log(err)
		       // renders index.ejs
    		res.render('author.ejs', {author: result, type:req.query.type })
  		})
	}else{
		res.render('author.ejs', {type:req.query.type})
	}
})


//delete selected author
app.delete('/authors', (req, res) => {
  db.collection('authors').deleteOne( {_id:ObjectId(req.body._id) },
  (err, result) => {
    if (err) return res.send(500, err)
    res.send({message: 'author got deleted'})
  })
})


app.post('/authors', (req,res) => {
	db.collection('authors').save(req.body, (err, result) => {
	    if (err) return console.log(err)

	    console.log('saved to database')
	    res.redirect('/')
  })
})

app.put('/authors', (req, res) => {
  db.collection('authors')
  .findOneAndUpdate({_id:ObjectId(req.body._id)}, {
    $set: {
      name: req.body.name,
      desc: req.body.desc
    }
  }, {
    sort: {_id: -1},
    upsert: true
  }, (err, result) => {
    if (err) return res.send(err)
    res.send(result)
  })
})


