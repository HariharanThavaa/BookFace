install an configure notes.

Extract the Bookface.zip in your machine.

navigate to that folder in command prompt.

type : npm run dev

which start the server on localhost 3000

Then open your browser and browse http://localhost:3000/


adminsistrator account.
user: 'bookfacethava@gmail.com',
pass: 'test@cbsd'

administrator and permisssions
==============================
Authors - CRUD
Book - CRUD
Comment - CRUD

other signed in users and permisssions
======================================
Authors - CR
Book - CR
Comment - CR

Without Sign in and permisssions
============================
Authors - R
Book - R
Comment - R


How to sign in?
Top left corner there is a button to signup
that will open the sign up window
type your screen name and mail id and submit
You will receive an email to your given mail account
click the link on the mail
You will be redirected to the application with welcome message.







