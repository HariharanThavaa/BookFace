const express = require('express');
const bodyParser = require('body-parser')
const app = express();
app.set('view engine','ejs')
app.use(bodyParser.json())
app.use(express.static('public'))
const MongoClient = require('mongodb').MongoClient

var uri = "mongodb://harimaniam:Password@cluster0-shard-00-00-kqjyc.mongodb.net:27017,cluster0-shard-00-01-kqjyc.mongodb.net:27017,cluster0-shard-00-02-kqjyc.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin";
var db

MongoClient.connect(uri, (err, database) => {
  if (err) return console.log(err)
  db = database.db('star-wars-quotes')
  app.listen(3000, () => {
    console.log('listening on 3000')
  })
})

app.use(bodyParser.urlencoded({extended: true}))

app.get('/', (req, res) => {
  db.collection('authors').find().toArray((err, result) => {
    if (err) return console.log(err)
    // renders index.ejs
    res.render('index.ejs', {authors: result})
  })
})


// Add/Edit/View Authors Screen
app.get('/authors', (req, res) => {
	if ((typeof(req.query.name) !== 'undefined') && (req.query.name!== null)) {
		db.collection('authors')
		  .findOne({name: req.query.name}, (err, result) => {
		   if (err) return console.log(err)
		       // renders index.ejs
    		res.render('author.ejs', {author: result})
  		})
	}else{
		res.render('author.ejs')
	}
})



app.post('/authors', (req,res) => {
	db.collection('authors').save(req.body, (err, result) => {
	    if (err) return console.log(err)

	    console.log('saved to database')
	    res.redirect('/')
  })
})

app.put('/quotes', (req, res) => {
  db.collection('quotes')
  .findOneAndUpdate({name: 'Appan'}, {
    $set: {
      name: req.body.name,
      quote: req.body.quote
    }
  }, {
    sort: {_id: -1},
    upsert: true
  }, (err, result) => {
    if (err) return res.send(err)
    res.send(result)
  })
})

app.delete('/quotes', (req, res) => {
  db.collection('quotes').findOneAndDelete({name: req.body.name},
  (err, result) => {
    if (err) return res.send(500, err)
    res.send({message: 'A darth vadar quote got deleted'})
  })
})

