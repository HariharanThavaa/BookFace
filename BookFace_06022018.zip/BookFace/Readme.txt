Extract the Bookface.zip in your machine.

navigate to that folder in command prompt.

type : npm run dev

which start the server on localhost 3000

Then open your browser and browse http://localhost:3000/